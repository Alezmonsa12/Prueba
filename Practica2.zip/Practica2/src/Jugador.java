import java.util.Scanner;
import java.util.ArrayList;

public class Jugador {

    // atributos
    ArrayList<Jugador> lstJugadores = new ArrayList<Jugador>();
    private int id;
    private String nombre;
    private String apellido;
    private String direccion;

    public Jugador() {

    }
    public Jugador(int Id, String Nombre, String Apellido, String Direccion) {

        nombre = Nombre;
        apellido = Apellido;
        direccion = Direccion;
        id = Id;
    }
    public void mostraOpciones(int opcion) {
        MenuPrincipal objMenuPrincipal = new MenuPrincipal();
        Scanner leer = new Scanner(System.in);
        opcion = objMenuPrincipal.menuPrincipal();
        if (opcion == 1) {
            mostraOpcion1(opcion);
        } else if (opcion == 2) {
            mostraopcion2(opcion);
        } else if (opcion == 3) {
            mostraopcion3(opcion);
        } else if (opcion == 4) {
            mostraopcion4(opcion);
        } else if (opcion == 5) {
            mostraopcion5(opcion);
        }
    }

    public void mostraOpcion1(int opcion) {
        Scanner leer = new Scanner(System.in);
        String nombre;
        String apellido;
        String direccion;

        // aca instanciamos la clase jugador
        System.out.println("ingrese el nombre del jugador");
        nombre = leer.nextLine();
        // objJugador.setNombre(nombre);
        System.out.println("ingrese el apellido del jugador");
        apellido = leer.next();
        //objJugador.setApellido(apellido);
        System.out.println("ingrese la direccion del jugador");
        direccion = leer.next();
        // objJugador.setDireccion(direccion);
        int id = (lstJugadores.size() + 1);
        Jugador objJugador = new Jugador(id , nombre, apellido, direccion );

        lstJugadores.add(objJugador);

        mostraJugador();

        mostraOpciones(opcion);
    }

    public void mostraopcion2(int opcion) {
        String respuesta;
        Scanner leer = new Scanner(System.in);
        int id = 0;
        boolean sw = false;
        System.out.println(" Por favor ingrese el código del jugador a eliminar : ");
        id = leer.nextInt();

        for (int i = 0; i < lstJugadores.size(); i++) {
            Jugador objJugador = new Jugador();
            objJugador = lstJugadores.get(i);

            if (objJugador.id == id) {

                System.out.println(" Ingrese S si confirma que desea eliminar el registro ");
                respuesta = leer.next();
                if (respuesta.equals("S")) {
                    lstJugadores.remove(i);
                }
                sw = true;
                i = lstJugadores.size();
            }
        }
        if (sw == true) {
            System.out.println(" Jugador eliminado con exito ");
        } else {
            System.out.println(" El jugador no fue encontrado ");
        }
                mostraOpciones(opcion);
    }

    public void mostraopcion3(int opcion) {
        Scanner leer = new Scanner(System.in);
        int id = 0;
        boolean sw = false;
        System.out.println(" Por favor ingrese el código del jugador a buscar : ");
        id = leer.nextInt();

        for (int i = 0; i < lstJugadores.size(); i++) {
            Jugador objJugador = new Jugador();
            objJugador = lstJugadores.get(i);

            if (objJugador.id == id) {
                System.out.println(" Los datos del jugador buscado son: " + objJugador.toString());
                sw = true;
                i = lstJugadores.size();
            }
        }

        if (sw == false) {
            System.out.println(" Jugador no encontrado ");
        }

       // mostraJugador();

        mostraOpciones(opcion);
    }

    public void mostraopcion4(int opcion) {
        Scanner leer = new Scanner(System.in);
        int id = 0;
        boolean sw = false;
        System.out.println(" Por favor ingrese el código del jugador a modificar : ");
        id = leer.nextInt();

        for (int i = 0; i < lstJugadores.size(); i++) {
            Jugador objJugador = new Jugador();
            objJugador = lstJugadores.get(i);

            if (objJugador.id == id) {
                System.out.println(" Los datos del jugador son : " + objJugador.toString());

                String nombre;
                String apellido;
                String direccion;
                String respuesta;

                System.out.println("");
                // aca instanciamos la clase jugador
                System.out.println("ingrese el nombre del jugador a modificar");
                nombre = leer.next();
                // objJugador.setNombre(nombre);
                System.out.println("ingrese el apellido del jugador a modificar");
                apellido = leer.next();
                //objJugador.setApellido(apellido);
                System.out.println("ingrese la direccion del jugador a modificar");
                direccion = leer.next();

                System.out.println("Para confirmar que desea modificar el registro ingrese S");
                respuesta = leer.next();

                if (respuesta.equals("S")) {
                    lstJugadores.remove(i);

                    Jugador objJugadorModificado = new Jugador(id, nombre, apellido, direccion);

                    lstJugadores.add(objJugadorModificado);
                } else {
                    System.out.println(" Jugador no modificado");

                }
                sw = true;
                i = lstJugadores.size();
            }

        }

        if (sw != true) {

            System.out.println(" El jugador no fue encontrado ");
        }

        mostraJugador();

        mostraOpciones(opcion);
    }

    public void mostraopcion5(int opcion) {
        mostraJugador();

        mostraOpciones(opcion);
    }

    public void mostraJugador() {
        System.out.println("***************************************************************");
        System.out.println("********************* LISTA DE JUGADORES **********************");
        for (Jugador objJugador : lstJugadores) {
            System.out.println(objJugador.toString());
        }
        System.out.println("******************* FIN LISTA DE JUGADORES ********************");
        System.out.println("***************************************************************");
        System.out.println("");
    }

    @Override
    public String toString() {
        return "Id : " + id + " Nombre : " + nombre + " Apellido : " + apellido + " Dirección : " + direccion;
    }

}
