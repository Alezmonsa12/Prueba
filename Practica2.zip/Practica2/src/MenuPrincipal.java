
import java.util.Scanner;
public class MenuPrincipal {

    public int menuPrincipal() {
        // este  metodo le muestra el  menuprincipal al usuario
        int opcion;
        Scanner leer = new Scanner(System.in);
        System.out.println("");
        System.out.println("**********************************************************");
        System.out.println("********************* MENÚ PRNCIPAL **********************");
        System.out.println("**************** 1. Agregar Jugador        ***************");
        System.out.println("**************** 2. Eliminar un jugador    ***************");
        System.out.println("**************** 3. Buscar un Jugador      ***************");
        System.out.println("**************** 4. Editar un Jugador      ***************");
        System.out.println("**************** 5. Lista de los Jugadores ***************");
        System.out.println("**************** 6. Salir del Programa     ***************");
        System.out.println("**********************************************************");
        System.out.println("Digite la Opcion");
        opcion = leer.nextInt();
        System.out.println("");
        // condicion para evaluar si el usuario ingreso una opcion valida
        if (opcion >= 1 & opcion <= 6) {
            // si el usuario ingreso una opcion valida le retorno la opcion ingresada a la clase main
            return opcion;
        } else {
            // en caso de que el usuarion no haya ingresado una opcion valida, con esta funcion hago que el sistema
            // le muestre de nuevo el menu pricipal
            menuPrincipal();
        }
        // esta linea la pongo por que el compilador me exige que haya un return
        return 0;
    }
}
