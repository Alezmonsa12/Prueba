package List;

public class list<T> {
}
